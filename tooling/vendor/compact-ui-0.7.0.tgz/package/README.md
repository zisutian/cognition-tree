# Compact UI

一套深色外观，统一配置颜色、字体、尺度和区域宽度。提供控件、表单、列表、弹层、受控目录树与桌面工作台。

本文对应 0.7.0，内容树可选用单选／无选择、菜单请求和作用域化拖放；原有集合选择阅读用法保持不变。升级前请查看[版本记录](CHANGELOG.md)及[0.6.0 → 0.7.0 接入说明](dist/API.md#从-060-迁移到-070)。历史安装包保持各自原有接口。

## 安装与入口

将交付包放到应用目录后安装，也可将路径替换为安装包的实际位置：

```sh
npm install ./compact-ui-0.7.0.tgz react@^19.2.6 react-dom@^19.2.6
```

包提供 ESM、TypeScript 声明和独立 CSS。宿主使用 React／React DOM `^19.2.6`（19.2.6 至 20.0.0 之前），并具备 CSS 导入能力。组件与类型从 `compact-ui` 导入，样式从 `compact-ui/styles.css` 导入一次。

## 最小接入

```tsx
import { CompactProvider, createDesignConfig, Button, Stack } from 'compact-ui';
import 'compact-ui/styles.css';

const config = createDesignConfig({
  colors: { accent: '#8ab4d6' },
  colorNames: { project: '#4ec9b0' },
  metrics: { rowHeight: 26, controlHeight: 26 },
  layout: { context: { default: 300 } },
});

export function App() {
  return <CompactProvider config={config}>
    <Stack direction="row"><Button>保存</Button></Stack>
  </CompactProvider>;
}
```

Provider 接收局部覆盖或完整配置，按输入对象引用复制、校验并冻结为只读运行时快照；useDesignConfig 返回 ReadonlyDesignConfig。就地修改输入不更新界面，传入新对象才生效；应用原对象不会被冻结。嵌套 Provider 不隐式继承外层配置。共享 defaultDesignConfig 在类型和运行时均深只读；createDesignConfig 返回独立、可修改的配置。透明按钮底色由 colors.plainButton 统一配置，默认 transparent。

所有组件及配置相关 hook 都在 `CompactProvider` 内使用。组件不开放 className/style 覆盖；在应用入口统一配置。

## 完整工作台

```tsx
import {
  CompactProvider, Workbench, useWorkbenchLayout,
  Section, Button,
} from 'compact-ui';
import 'compact-ui/styles.css';

function Workspace() {
  const layout = useWorkbenchLayout();
  return (
    <Workbench
      {...layout}
      context={{ title: '导航', content: <p>放置目录树或业务导航</p> }}
      main={{
        title: '工作区',
        content: <Section title="内容"><Button>保存</Button></Section>,
      }}
      detail={{ title: '详情', content: <p>放置当前内容的属性</p> }}
      status={{ start: '就绪' }}
    />
  );
}

export function App() {
  return <CompactProvider fill><Workspace /></CompactProvider>;
}
```

宿主负责容器高度，例如在应用自身样式中设置 `html, body, #root { height: 100%; margin: 0; }`。`useWorkbenchLayout` 放在 Provider 的子组件中，读取当前配置并管理布局变化。业务按钮的回调、数据与保存流程由应用提供。

## 状态与组件职责

按钮以 `appearance="filled" | "plain"` 控制有背景／无背景，`tone="neutral" | "danger"` 控制语义，`iconOnly` 控制图标布局。三个维度可组合，例如 `<Button appearance="plain" tone="danger" iconOnly aria-label="删除">…</Button>`。Button、ToggleButton、SubButton 均支持 DOM ref；ToggleButton 的 pressed 保持受控，可通过 onPressedChange 接收新状态。

使用 `List`／`ListProps` 配置普通列表。`columns={3}` 固定每行三列并自动换行，列宽均分可用空间；`columns="auto"` 按容器宽度调整列数。默认仍是一列，`rowGap`、`columnGap` 分别配置行列间距。自适应模式的最小列宽通过 `createDesignConfig({ layout: { listMinColumnWidth: 180 } })` 配置，数字列数不受该值限制。行统一使用 `ListRow`：默认 `layout="compact"` 展示紧凑图标行；`layout="detailed"` 展示 title 与 description。两种排布都支持 icon、selected、onSelect、actions；省略 onSelect 时作为非交互展示。

从 0.1.0 升级到当前版本时，将 `ContextList`、`ManagementList` 改为 `List`，并把 `ContextRow`、`ManagementRow` 改为 `ListRow`；紧凑行的 children 改为 title，说明行设置 `layout="detailed"`。容器在 0.2.0、行组件在 0.4.0 分别收束；已封存的历史安装包仍使用各自原有接口。

Tree 的节点、选中与展开均受控；重命名、删除、移动回调可以异步返回，数据更新由宿主完成。行为关闭时不显示对应入口。Workbench 的导航只发出请求，由宿主决定是否切换。

`ContentTree` 依次呈现类型、单行正文摘要、诊断和位置。节点的 `text` 必填，用于默认正文、无障碍名称、前缀查找和完整提示；可选 `content` 保留加粗、斜体、颜色等非交互行内格式。`position.label` 由应用提供，例如 `L2–3`；`diagnostic` 由应用汇总为错误、警告或提示。组件不解析领域文档，也不内置编辑、删除、实际数据移动或预览／固定。

```tsx
import { useRef, useState } from 'react';
import { ContentTree, type ContentTreeHandle, type ContentTreeNode } from 'compact-ui';

const contentNodes: readonly ContentTreeNode[] = [
  { id: 'chapter', text: '章节摘要', typeLabel: '章节', position: { label: 'L1–3' }, children: [
    { id: 'body', text: '可以保留行内格式', position: { label: 'L2', description: '第 2 行' },
      diagnostic: { severity: 'warning', message: '待复核' },
      content: <>可以保留<strong>行内格式</strong></> },
  ] },
];

// 放在 CompactProvider 内；应用持有选择与展开状态。
function ContentOutline() {
  const [selectedIds, setSelectedIds] = useState<ReadonlySet<string>>(new Set());
  const [expandedIds, setExpandedIds] = useState<ReadonlySet<string>>(new Set(['chapter']));
  const treeRef = useRef<ContentTreeHandle>(null);
  return <>
    <button onClick={() => treeRef.current?.reveal('body')}>定位正文</button>
    <ContentTree ref={treeRef} aria-label="内容结构" nodes={contentNodes} indentScale={1.25}
      selectedIds={selectedIds} onSelect={id => setSelectedIds(new Set([id]))}
      expandedIds={expandedIds} onExpandedChange={setExpandedIds} />
  </>;
}
```

点击父节点整行同时请求选择与展开／收起；应用决定选中集合，可自行实现后代选择。更新集合不会自动展开祖先或抢走外部焦点。`reveal(id)` 仅定位已可见节点，也不修改这些状态。内容始终单行省略；行高由 `ceil(fontSize × max(lineHeight, 1))` 派生，默认 18px，独立于普通控件高度；缩进由 `metrics.treeIndent × indentScale` 决定。超过 500 个可见节点使用虚拟滚动。省略 `scrollContainer` 时树自行滚动；传入包含树的外层 `HTMLElement` 时，树按内容占位并由该元素滚动；宿主未挂载时传 `null`。不提供 ContentTreeRow、行渲染器或高度／外观覆盖参数。完整属性与键盘规则见随包 `dist/API.md`。

0.7.0 的选择模式可按业务选择：默认 `selectionMode="collection"` 保留 `selectedIds`；`selectionMode="single"` 使用 `selectedId`；`selectionMode="none"` 不传选择值和 `onSelect`。三种模式仍由应用控制数据。可选 `onRequestContextMenu` 接收右键／菜单键请求，不自动选择节点。

如需拖放，把相关内容树放进同一个 `ContentTreeDragScope`，为每棵树提供作用域内唯一的 `treeId`、数据集身份 `contentKey`，以及同步的 `canDrag`／`canDrop` 许可。作用域的 `onMoveRequest` 只通知应用移动意图；应用决定如何移动、保存、拒绝与恢复失败，不能把拖动结束当作保存成功。最小接线如下：

```tsx
import { ContentTree, ContentTreeDragScope, type ContentTreeMoveRequest, type ContentTreeNode } from 'compact-ui';

function MovableOutline({ nodes, expandedIds, setExpandedIds, move }: {
  nodes: readonly ContentTreeNode[];
  expandedIds: ReadonlySet<string>;
  setExpandedIds(ids: ReadonlySet<string>): void;
  move(request: ContentTreeMoveRequest): void;
}) {
  return <ContentTreeDragScope onMoveRequest={move}>
    <ContentTree aria-label="文档结构" nodes={nodes} selectionMode="none"
      expandedIds={expandedIds} onExpandedChange={setExpandedIds}
      dragDrop={{ treeId: 'outline', contentKey: 'document-42',
        canDrag: id => id !== 'locked', canDrop: () => true }} />
  </ContentTreeDragScope>;
}
```

`contentKey` 只在切换数据集时改变，普通节点更新保持不变。放下时可得到目标节点的 `before`／`inside`／`after`，或内容末尾的 `root-end`。不启用 `dragDrop` 时无需作用域；完整限制、菜单与焦点规则见随包 `dist/API.md`。

`StatusText` 统一展示单行状态文字。`mode="live"` 使用 `tone` 或 `colorName` 表达当前状态；`mode="snapshot"`（默认）以正文颜色展示某时刻的记录，不接受颜色参数。两者共用 `typography.statusFontFamily`，默认等宽字体，不添加边框或背景。

左侧打开入口通过 `OpenIntent` 表达单击 preview 与双击 pinned：Workbench 的 `onActivityRequest(id, intent)` 和 Tree 的可选 `onOpen(id, intent)` 使用相同语义，单击无需等待双击判定。PageTitleGroup 标题选项的 `preview` 只控制临时预览的斜体提示；示例中标题栏只切换、关闭已打开页面，打开与固定均由左侧入口触发。

`SubButton` 是独立的子操作按钮，用于标题关闭与行内操作。默认使用图标布局，继承选中父项的背景层次；文字操作设置 `iconOnly={false}`，危险语义设置 `tone="danger"`，`compact` 适配紧凑行。父项未选中时传入 `parentSelected={false}`，隐藏子操作并保留占位。它保留 Button 的 ref、禁用和原生事件能力，只渲染一个按钮。

```tsx
import { SubButton } from 'compact-ui';

<SubButton iconOnly={false} parentSelected={selected} onClick={rename}>重命名</SubButton>
```

框架图标使用 `<Button iconOnly appearance="plain" />` 预设，用于面板、活动导航与区域收放；默认透明，悬停和选中沿用统一反馈。选中行的附属操作继续使用 SubButton。工作台的导航与资源目录贯穿全高；底部状态栏位于右侧内容区下方，只保留底栏开关，正文折叠时依然显示状态信息。

## 文档与支持范围

- [完整接口与组合说明](dist/API.md)
- [版本记录](CHANGELOG.md)
- [来源与许可](NOTICE.md)，许可证为 GPL-3.0-or-later，全文见 LICENSE。

本版面向桌面浏览器应用，自动化验证使用 Chromium，覆盖键盘、焦点、拖动、窄屏布局和页面缩放。Firefox、Safari、触屏及服务端渲染尚未纳入当前验证。原生选择菜单在不支持可定制 select 的浏览器中使用系统外观。

本包来自 Cognition Tree 可用版的通用视觉及交互基础，已移除领域模型、网络与存储依赖。完整源码交付物包含工作台与全场景演示，以及构建与验证工具。
