# Compact UI

一套深色外观，统一配置颜色、字体、尺度和区域宽度。提供控件、表单、列表、弹层、受控目录树与桌面工作台。

本文对应 0.3.1，修正 ColorPicker 文字排版并缩短默认宽度；0.3.0 起使用该组件替换旧颜色组件。升级前请查看[版本记录](CHANGELOG.md)及[接口迁移说明](dist/API.md)。已交付的 0.1.0 安装包保持原接口。

## 安装与入口

将交付包放到应用目录后安装，也可将路径替换为安装包的实际位置：

```sh
npm install ./compact-ui-0.3.1.tgz react@^19.2.6 react-dom@^19.2.6
```

包提供 ESM、TypeScript 声明和独立 CSS。宿主使用 React／React DOM `^19.2.6`（19.2.6 至 20.0.0 之前），并具备 CSS 导入能力。组件与类型从 `compact-ui` 导入，样式从 `compact-ui/styles.css` 导入一次。

## 最小接入

```tsx
import { CompactProvider, createDesignConfig, Button, Stack } from 'compact-ui';
import 'compact-ui/styles.css';

const config = createDesignConfig({
  colors: { accent: '#8ab4d6' },
  colorNames: { project: '#4ec9b0' },
  metrics: { rowHeight: 26, controlHeight: 26 },
  layout: { context: { default: 300 } },
});

export function App() {
  return <CompactProvider config={config}>
    <Stack direction="row"><Button>保存</Button></Stack>
  </CompactProvider>;
}
```

共享 defaultDesignConfig 在类型和运行时均深只读；createDesignConfig 返回独立、可修改的配置。透明按钮底色由 colors.plainButton 统一配置，默认 transparent。

所有组件及配置相关 hook 都在 `CompactProvider` 内使用。组件不开放 className/style 覆盖；在应用入口统一配置。

## 完整工作台

```tsx
import {
  CompactProvider, Workbench, useWorkbenchLayout,
  Section, Button,
} from 'compact-ui';
import 'compact-ui/styles.css';

function Workspace() {
  const layout = useWorkbenchLayout();
  return (
    <Workbench
      {...layout}
      context={{ title: '导航', content: <p>放置目录树或业务导航</p> }}
      main={{
        title: '工作区',
        content: <Section title="内容"><Button>保存</Button></Section>,
      }}
      detail={{ title: '详情', content: <p>放置当前内容的属性</p> }}
      status={{ start: '就绪' }}
    />
  );
}

export function App() {
  return <CompactProvider fill><Workspace /></CompactProvider>;
}
```

宿主负责容器高度，例如在应用自身样式中设置 `html, body, #root { height: 100%; margin: 0; }`。`useWorkbenchLayout` 放在 Provider 的子组件中，读取当前配置并管理布局变化。业务按钮的回调、数据与保存流程由应用提供。

## 状态与组件职责

按钮以 `appearance="filled" | "plain"` 控制有背景／无背景，`tone="neutral" | "danger"` 控制语义，`iconOnly` 控制图标布局。三个维度可组合，例如 `<Button appearance="plain" tone="danger" iconOnly aria-label="删除">…</Button>`。四类按钮均支持 DOM ref；ToggleButton 的 pressed 保持受控，可通过 onPressedChange 接收新状态。

0.2.0 统一使用 `List`／`ListProps` 配置普通列表。`columns={3}` 固定每行三列并自动换行，列宽均分可用空间；`columns="auto"` 按容器宽度调整列数。默认仍是一列，`rowGap`、`columnGap` 分别配置行列间距。自适应模式的最小列宽通过 `createDesignConfig({ layout: { listMinColumnWidth: 180 } })` 配置，数字列数不受该值限制。`ContextRow` 展示紧凑图标行，`ManagementRow` 展示名称与说明，二者都放在 `List` 内。

从 0.1.0 升级时，需要将 `ContextList`、`ManagementList` 的导入及 JSX 标签改为 `List`，原有子行可保留。这是 0.2.0 的不兼容变更；已封存的 0.1.0 安装包仍使用旧接口。

Tree 的节点、选中与展开均受控；重命名、删除、移动回调可以异步返回，数据更新由宿主完成。行为关闭时不显示对应入口。Workbench 的导航只发出请求，由宿主决定是否切换。

`StatusText` 统一展示单行状态文字。`mode="live"` 使用 `tone` 或 `colorName` 表达当前状态；`mode="snapshot"`（默认）以正文颜色展示某时刻的记录，不接受颜色参数。两者共用 `typography.statusFontFamily`，默认等宽字体，不添加边框或背景。

左侧打开入口通过 `OpenIntent` 表达单击 preview 与双击 pinned：Workbench 的 `onActivityRequest(id, intent)` 和 Tree 的可选 `onOpen(id, intent)` 使用相同语义，单击无需等待双击判定。PageTitleGroup 标题选项的 `preview` 只控制临时预览的斜体提示；示例中标题栏只切换、关闭已打开页面，打开与固定均由左侧入口触发。

`SubButton` 是独立的子操作按钮，用于标题关闭与行内操作。默认使用图标布局，继承选中父项的背景层次；文字操作设置 `iconOnly={false}`，危险语义设置 `tone="danger"`，`compact` 适配紧凑行。父项未选中时传入 `parentSelected={false}`，隐藏子操作并保留占位。它保留 Button 的 ref、禁用和原生事件能力，只渲染一个按钮。

```tsx
import { SubButton } from 'compact-ui';

<SubButton iconOnly={false} parentSelected={selected} onClick={rename}>重命名</SubButton>
```

`FrameButton` 用于面板、活动导航与区域收放的框架图标，未选中时默认透明，悬停和选中沿用统一反馈。它与具有独立底色的普通 Button、依附选中父项的 SubButton 分工明确。工作台的导航与资源目录贯穿全高；底部状态栏位于右侧内容区下方，只保留底栏开关，正文折叠时依然显示状态信息。

## 文档与支持范围

- [完整接口与组合说明](dist/API.md)
- [版本记录](CHANGELOG.md)
- [来源与许可](NOTICE.md)，许可证为 GPL-3.0-or-later，全文见 LICENSE。

本版面向桌面浏览器应用，自动化验证使用 Chromium，覆盖键盘、焦点、拖动、窄屏布局和页面缩放。Firefox、Safari、触屏及服务端渲染尚未纳入当前验证。原生选择菜单在不支持可定制 select 的浏览器中使用系统外观。

本包来自 Cognition Tree 可用版的通用视觉及交互基础，已移除领域模型、网络与存储依赖。完整源码交付物包含工作台与全场景演示，以及构建与验证工具。
