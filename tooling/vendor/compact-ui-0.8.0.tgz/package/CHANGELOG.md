# 版本记录

## 0.8.0 — 2026-10-04

- Tree 与 ContentTree 共用受控集合选择，支持 single、multiple、none；目录默认 single，内容默认 multiple。范围选择包含未挂载行，折叠保留隐藏选择，焦点与目录打开意图保持独立。
- 两类树通过 TreeDragScope 共用批量移动、源规范化、许可、提交互斥与明确回执；工具栏可用 beginMove 启动移动，全部源隐藏时仍可使用。业务负责整批修改、保存及失败恢复。
- 不兼容变更：统一使用 selectedIds／onSelectionChange，移除 selectedId／onSelect、collection、旧单源目录移动入口及 ContentTreeDragScope 等旧协议，不保留兼容别名。onMoveRequest 必须返回 TreeMoveResult 或其 Promise。
- 菜单在首次提交中判定选择，等待坐标时保持该快照；共用有界定位、Escape 取消、身份失效及迟到结果隔离。目录编辑、删除和输入法边界保持各自职责。
- 工作台、全场景示例及独立安装消费同步迁移，新增多选拖动与菜单行为回归。完整升级步骤见接口文档的 0.7.1 → 0.8.0 迁移专题。

## 0.7.1 — 2026-09-28

- Tree 与 ContentTree 共用结构索引及可见导航投影；深树的移动候选判断避免重复扫描祖先，焦点、展开和业务许可规则保持不变。
- 大树窗口复用稳定的行索引与几何；外部滚动宿主尚未就绪时保留总高度和必要行，不全量挂载。内容树拖放按参与树通知更新，无关树不随落点移动重复呈现。
- QuickPick 缓存选项搜索文本与可用项索引，超过 500 个匹配项时使用虚拟滚动，并按实际换行行高定位。筛选、键盘、焦点和选择回调顺序保持不变。
- 浮层、分隔条和工作台跳过结果相同的状态更新；受控尺寸请求遭宿主拒绝后仍可再次发起。公开 API、依赖和默认交互均未变，0.7.0 调用方无需迁移。

## 0.7.0 — 2026-09-27

- ContentTree 保留默认集合选择，并新增 `selectionMode="single"` 与 `selectionMode="none"`；三种模式的受控属性由类型分别约束，焦点与选择仍独立。无选择模式的 Enter／Space 可展开或收起父节点。
- 新增 `onRequestContextMenu`，右键、菜单键和 Shift+F10 统一请求宿主菜单；仅更新活动行和焦点，不自动选择。菜单内容和业务动作由应用提供。
- 新增可选 `ContentTreeDragScope` 与 `dragDrop`：同一作用域内允许按宿主许可拖动到节点上方、内部、下方或内容末尾，并向应用发出一次 `ContentTreeMoveRequest`。组件管理拖动反馈、循环限制、当前宿主边缘滚动及失效清理；应用仍负责实际移动、保存与失败恢复。未启用时保持原有阅读用法。
- 现有全场景示例加入真实内容移动、菜单与“移动到…”选择器；独立安装包验证覆盖内容树结构请求。`start-demo.sh` 仍只在开发仓库及源码归档中，不新增开发 demo，不进入组件安装包。

## 0.6.0 — 2026-09-27

- 不兼容变更：ContentTree 节点的 `lineNumber` 改为 `position: { label, description? }`。位置文字由应用提供，允许行号或范围，不参与身份、排序和选择；原字段不保留别名。
- ContentTree 新增 `diagnostic`，统一呈现错误、警告和提示的图标、语义颜色及辅助说明；新增独立 `indentScale`，每层缩进使用 `metrics.treeIndent × indentScale`，行高继续由字号和行距派生。
- ContentTree 可借用外层 `scrollContainer`，并通过 `ContentTreeHandle.reveal(id)` 将已可见节点滚入视口，不改变选择、展开和焦点。内部滚动保持默认；支持树前后内容、动态偏移、宿主替换和大树虚拟滚动。
- Tree 与 ContentTree 共用显式栈层级遍历，深链不再依赖递归调用栈。ContentTree 已有焦点失效时回退到最近可见可用祖先，再回退首行或树容器；目录 Tree 的操作回焦规则保持不变。
- 现有全场景示例增加内容树的外部滚动与定位操作；开发仓库内原有 `start-demo.sh` 保持不变。组件包不包含示例或启动脚本。

## 0.5.0 — 2026-09-26

- 新增只读 ContentTree、ContentTreeProps、ContentTreeNode，展示类型、单行正文和行号；选择集合与展开由应用控制。阅读行高由字号和行距派生，独立于普通控件尺寸。
- Tree 与 ContentTree 内部共享结构索引、导航、前缀查找、焦点与定高虚拟滚动；目录操作及异步会话继续由 Tree 独占。新增内容阅读示例和实际 tgz 消费验证。
- Tree 的输入与视图统一调用完整操作，控制器拥有操作许可、会话、错误与焦点去向；保存中拒绝取消和重复提交，迟到结果不再污染失效会话，虚拟行按焦点请求挂载。
- Provider 接收局部配置，创建独立只读快照；新增 ReadonlyDesignConfig，useDesignConfig 不再允许写入配置。配置更新须替换输入对象。
- 独立消费验证拆为真实 TSX 样例与分组检查；失败清除旧成功报告并释放浏览器和服务。

## 0.4.0 — 2026-09-22

- Toolbar 与 FormActions 共享操作排布样式，保留各自间距、分组语义与表单对齐；EmptyState 由 Stack 组合实现并保留便捷入口，状态栏与空态各归独立文件。

- 不兼容变更：以 ListRow / ListRowProps 统一 ContextRow 与 ManagementRow，保留 compact / detailed 排布、非交互展示、说明换行和独立操作区；两种排布均支持图标。

- 不兼容变更：移除 FrameButton / FrameButtonProps，框架图标改用 Button 的 iconOnly 与 appearance="plain" 组合；仓内调用一次迁移。

- 修正 PageTitleGroup 中文斜体标题的边缘裁切；为笔画保留空间，固定页面时标题宽度不跳动，保留长标题省略与关闭按钮布局。

## 0.3.1 — 2026-09-22

- 修正 ColorPicker 触发按钮与预设选项的文字裁切，文字在完整可用高度内居中。
- 默认 colorPickerWidth 从 160px 缩短为 112px，减少空白；保留配置宽度与 sizing="fill"。公共接口及选择、保存行为保持不变。

## 0.3.0 — 2026-09-22

- 用 ColorPicker 替换 ColorControl：统一当前色块／名称展示、预设选择、自定义色值、只读与禁用；保留受控值、字段关联和按钮 ref。
- 不兼容变更：onChange 改为直接接收颜色字符串，ref 改为 HTMLButtonElement；layout.colorControlWidth 更名 colorPickerWidth，默认 160px。仓内示例同步迁移，旧组件与样式删除。
- 修复模态浮层点击遮罩关闭时焦点被浏览器默认行为夺走的问题；非模态浮层保留原有外部点击行为。

## 0.2.0 — 2026-09-22

本版整理公共接口，包含不兼容变更。应用需按随包 API 文档的迁移表一次迁移，不保留旧参数别名。

- 默认配置在类型和运行时递归冻结，createDesignConfig 仍返回独立可修改的配置；移除未使用的 accentHover，frameButton 配色更名为所有透明按钮共用的 plainButton。完整迁移表见 API 文档。

- 不兼容变更：组件的无障碍名称统一为 aria-label，移除 ariaLabel 和仅用于辅助技术命名的 label；可见内容与数据项的 label 保持不变。

- 不兼容变更：sizing 从 content／container 更名为 default／fill，保持输入、下拉、文本域和滑条原有尺寸及默认行为。

- 不兼容变更：ChoiceGroup 移除 onClose、closeLabel、preview；页面标题迁移到独立 PageTitleGroup，保留受控状态、关闭拒绝、焦点转移及长标题滚动。

- CheckboxGroup 采用最小 SelectionOption 类型，移除实际未使用的 title、closeLabel、preview 字段，并独立组件职责。

- 不兼容变更：按钮移除 variant，以 appearance、tone、iconOnly 分别表达背景、危险语义与图标布局。ToggleButton 新增 ref 与受控 onPressedChange；无背景按钮保留交互反馈。

- 普通列表容器统一为 `List`／`ListProps`，支持列数、自动换行及行列间距配置，保留默认单列布局和原有行交互。
- 不兼容变更：移除 `ContextList` 和 `ManagementList` 容器入口，调用方需将导入及 JSX 标签替换为 `List`。ContextRow、ManagementRow 的接口保持不变。
- 数字 `columns` 表示固定列数，均分容器宽度，修正三列与四列在侧栏展开时可能显示相同列数的问题；只有 `columns="auto"` 随宽度调整列数。
- 统一设计配置新增 `layout.listMinColumnWidth`，仅用于自适应列数模式。
- 展示场景支持单列、双列、三列、四列、自适应排列及间距切换。

## 0.1.0 — 2026-09-21

Compact UI 首个可交付版本，面向 React 19 桌面工具应用。

### 提供的能力

- 在 CompactProvider 中统一配置颜色、字体、控件尺寸、间距与工作台区域尺度，样式限定于 Provider 范围。
- 普通按钮、框架按钮、子操作按钮、输入、选择、复选、颜色和滑块控件，支持禁用、错误、键盘和焦点反馈。
- 面板、分组、表单、列表、属性与状态展示，以及共享配置的菜单、弹层和搜索选择器。
- 受控目录树，包含按能力启用的重命名、删除、移动、异步错误保留和大列表窗口化。
- 受控工作台布局，包含活动导航、上下文区、主区、详情、底部面板、折叠、专注模式和缩放后的分隔条拖动。
- 工作台示例与 8 个可操作的展示场景，业务数据在应用层持有。

### 包与验证

- ESM、TypeScript 声明、独立 CSS、接口文档、来源说明及 GPL-3.0-or-later 许可证随包提供。
- 交付目录包含安装包、对应源码归档、版本说明、文件校验和与验证清单。
- 验证覆盖类型、依赖边界、单元测试、浏览器交互，以及实际安装打包产物后的独立应用接入。

这是初始 `0.x` 接口基线；后续不兼容变化会在次版本的版本记录中注明。首版自动化浏览器为 Chromium，其他浏览器与服务端渲染不在当前验证范围内。
