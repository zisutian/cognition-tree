# Compact UI

面向桌面浏览器应用的 React 组件库，以统一配置提供控件、表单、列表、浮层、目录树、内容树与工作台。

版本变化见 [CHANGELOG](CHANGELOG.md)，从旧版升级时按[0.7.1 → 0.8.0 迁移说明](dist/API.md#从-071-迁移到-080)调整树的选择与移动调用；安装包版本以包清单为准。

## 安装与入口

将交付包放到应用目录后安装，也可将路径替换为安装包的实际位置：

```sh
npm install ./compact-ui-0.8.0.tgz react@^19.2.6 react-dom@^19.2.6
```

包提供 ESM、TypeScript 声明和独立 CSS。宿主使用 React／React DOM `^19.2.6`，并具备 CSS 导入能力。组件与类型从 `compact-ui` 导入，样式从 `compact-ui/styles.css` 导入一次。

## 最小接入

```tsx
import { CompactProvider, createDesignConfig, Button, Stack } from 'compact-ui';
import 'compact-ui/styles.css';

const config = createDesignConfig({
  colors: { accent: '#8ab4d6' },
  colorNames: { project: '#4ec9b0' },
  metrics: { rowHeight: 26, controlHeight: 26 },
  layout: { context: { default: 300 } },
});

export function App() {
  return <CompactProvider config={config}>
    <Stack direction="row"><Button>保存</Button></Stack>
  </CompactProvider>;
}
```

所有组件及配置读取 hook 都在 `CompactProvider` 内使用。应用通过配置对象统一外观；更新时传入新对象，组件不开放 `className`／`style` 覆盖内部样式。配置快照、嵌套 Provider 与只读约束见[应用入口](dist/API.md#应用入口)。业务数据、回调及保存流程由应用提供。

## 完整工作台

```tsx
import {
  CompactProvider, Workbench, useWorkbenchLayout,
  Section, Button,
} from 'compact-ui';
import 'compact-ui/styles.css';

function Workspace() {
  const layout = useWorkbenchLayout();
  return (
    <Workbench
      {...layout}
      context={{ title: '导航', content: <p>放置目录树或业务导航</p> }}
      main={{
        title: '工作区',
        content: <Section title="内容"><Button>保存</Button></Section>,
      }}
      detail={{ title: '详情', content: <p>放置当前内容的属性</p> }}
      status={{ start: '就绪' }}
    />
  );
}

export function App() {
  return <CompactProvider fill><Workspace /></CompactProvider>;
}
```

宿主负责容器高度，例如在应用自身样式中设置 `html, body, #root { height: 100%; margin: 0; }`。`useWorkbenchLayout` 放在 Provider 的子组件中，读取当前配置并管理布局变化。业务按钮的回调、数据与保存流程由应用提供。

区域参数与导航请求见[工作台接口](dist/API.md#工作台)。

## 按需求查阅接口

| 需求 | 入口 |
|---|---|
| 按钮、输入、选择与颜色 | [组件组合](dist/API.md#组件组合) |
| 列表排列、行选择与独立操作 | [列表与状态](dist/API.md#列表与状态) |
| 字段标签、校验错误与表单布局 | [表单与列表内容](dist/API.md#表单与列表内容) |
| 目录重命名、删除、移动与异步失败处理 | [目录树](dist/API.md#目录树) |
| 层级内容阅读、选择模式与外部滚动 | [内容树](dist/API.md#内容树与可选结构操作) |
| 两类树的多选、菜单／工具栏与批量移动 | [树的选择与移动](dist/API.md#树的选择与移动) |
| 菜单、搜索选择与焦点恢复 | [弹层](dist/API.md#弹层) |

完整接口说明随包位于 `dist/API.md`；应用通过包根公开入口使用能力，内部行组件和 hook 不作为接入接口。

## 支持范围与来源

本版面向桌面浏览器应用，自动化验证使用 Chromium，覆盖键盘、焦点、拖动、窄屏布局和页面缩放。Firefox、Safari、触屏及服务端渲染尚未纳入当前验证。原生选择菜单在不支持可定制 select 的浏览器中使用系统外观。

组件安装包提供库与接入文档；对应源码交付物另含工作台、全场景演示、测试与构建工具。来源及依赖许可见 [NOTICE](NOTICE.md)，许可证全文见 [LICENSE](LICENSE)。
