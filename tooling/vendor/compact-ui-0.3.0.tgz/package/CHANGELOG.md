# 版本记录

## 0.3.0 — 2026-09-22

- 用 ColorPicker 替换 ColorControl：统一当前色块／名称展示、预设选择、自定义色值、只读与禁用；保留受控值、字段关联和按钮 ref。
- 不兼容变更：onChange 改为直接接收颜色字符串，ref 改为 HTMLButtonElement；layout.colorControlWidth 更名 colorPickerWidth，默认 160px。仓内示例同步迁移，旧组件与样式删除。
- 修复模态浮层点击遮罩关闭时焦点被浏览器默认行为夺走的问题；非模态浮层保留原有外部点击行为。

## 0.2.0 — 2026-09-22

本版整理公共接口，包含不兼容变更。应用需按随包 API 文档的迁移表一次迁移，不保留旧参数别名。

- 默认配置在类型和运行时递归冻结，createDesignConfig 仍返回独立可修改的配置；移除未使用的 accentHover，frameButton 配色更名为所有透明按钮共用的 plainButton。完整迁移表见 API 文档。

- 不兼容变更：组件的无障碍名称统一为 aria-label，移除 ariaLabel 和仅用于辅助技术命名的 label；可见内容与数据项的 label 保持不变。

- 不兼容变更：sizing 从 content／container 更名为 default／fill，保持输入、下拉、文本域和滑条原有尺寸及默认行为。

- 不兼容变更：ChoiceGroup 移除 onClose、closeLabel、preview；页面标题迁移到独立 PageTitleGroup，保留受控状态、关闭拒绝、焦点转移及长标题滚动。

- CheckboxGroup 采用最小 SelectionOption 类型，移除实际未使用的 title、closeLabel、preview 字段，并独立组件职责。

- 不兼容变更：按钮移除 variant，以 appearance、tone、iconOnly 分别表达背景、危险语义与图标布局。ToggleButton 新增 ref 与受控 onPressedChange；无背景按钮保留交互反馈。

- 普通列表容器统一为 `List`／`ListProps`，支持列数、自动换行及行列间距配置，保留默认单列布局和原有行交互。
- 不兼容变更：移除 `ContextList` 和 `ManagementList` 容器入口，调用方需将导入及 JSX 标签替换为 `List`。ContextRow、ManagementRow 的接口保持不变。
- 数字 `columns` 表示固定列数，均分容器宽度，修正三列与四列在侧栏展开时可能显示相同列数的问题；只有 `columns="auto"` 随宽度调整列数。
- 统一设计配置新增 `layout.listMinColumnWidth`，仅用于自适应列数模式。
- 展示场景支持单列、双列、三列、四列、自适应排列及间距切换。

## 0.1.0 — 2026-09-21

Compact UI 首个可交付版本，面向 React 19 桌面工具应用。

### 提供的能力

- 在 CompactProvider 中统一配置颜色、字体、控件尺寸、间距与工作台区域尺度，样式限定于 Provider 范围。
- 普通按钮、框架按钮、子操作按钮、输入、选择、复选、颜色和滑块控件，支持禁用、错误、键盘和焦点反馈。
- 面板、分组、表单、列表、属性与状态展示，以及共享配置的菜单、弹层和搜索选择器。
- 受控目录树，包含按能力启用的重命名、删除、移动、异步错误保留和大列表窗口化。
- 受控工作台布局，包含活动导航、上下文区、主区、详情、底部面板、折叠、专注模式和缩放后的分隔条拖动。
- 工作台示例与 8 个可操作的展示场景，业务数据在应用层持有。

### 包与验证

- ESM、TypeScript 声明、独立 CSS、接口文档、来源说明及 GPL-3.0-or-later 许可证随包提供。
- 交付目录包含安装包、对应源码归档、版本说明、文件校验和与验证清单。
- 验证覆盖类型、依赖边界、单元测试、浏览器交互，以及实际安装打包产物后的独立应用接入。

这是初始 `0.x` 接口基线；后续不兼容变化会在次版本的版本记录中注明。首版自动化浏览器为 Chromium，其他浏览器与服务端渲染不在当前验证范围内。
